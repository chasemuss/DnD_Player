# Danielle
Current Status: #DnD/Levasa/Alive 
## Known Relatives

## Known Locations

## Goals & Desires

## Detests

## Flaws

## Pseudonyms

## Other Information
- Dwarf
- Priestess of [[Chauntea]]
- [[Eiden]]'s Spy in [[Chauntea's Hearth]]