# Session 4: Cultists & 'Shrooms
## Recap
## Plot
We talk with the [[Cultists of Seed|Cultist of Seed]] and he asks if we are willing to submit ourselves to Seed. I asked what that entails. He says that it requires faith. I offer to heal him in exchange for him to not be aggressive with our party. I heal him & [[Lorenzo]] talks about the similarities between him being a follower of [[Church of Bahamut|Bahamut]] and the Cultists following Seed.

The cultist says that [[Tanoq]] has Bane's eyes and holds a #DnD/Levasa/Amber/Nucleus. [[Dedera]] asks him why he follows Seed and the cultist says, "I achieved enlightenment and that why I follow him. He is the truth. If you saw the light, you would too. If you saw the glow." He describes the glow as "all around us. In his eyes (pointing to Tanoq) in the sky and in the water." He confirms that he can see traces of amber and that the more faith one has in Seed, the more of a vessel of Seed you become and the more blessings he bestows on you. He says that amber is his power & his prison. 

After helping heal him, he hands me a syringe with #DnD/Levasa/Amber/Liquid and hands it to me. He says that it is all he has and that I can do with it as I please, although I can learn more about Seed by going to the Section 12 Lab in Heartbeat. They can tell me more about the #DnD/Levasa/Amber/Liquid. 

He says that all he wants from me is to truly find faith and the amber glow of Seed. 

He then pulls out another vial of orange liquid and downs it. This causes his body to morph. His arms and legs start to contort. He goes rigid & stiff, then black & orange bark-like figure start to come out of his body. Leaves sprout from it and his body is ripped open as a Treent makes its way out of him. The Treent grows into a giant monster and has spores from its back turn into 2 additional Treents. We enter combat with the creatures, but after a few interactions, we determine to run away. The Treents start to attack the flumphs and kill all but one of them.

Tanoq sends off a few fireballs and defeats the larger of the Treents, causing all three of them to fall. He then cast _Spare the Dying_ and failed to save a dead/dying flumph. 

Azazel also summoned a Zombie-esque monster, and that caused problems with the party. 

Dedera says that Azazel looks like Kreth with his _Form of Dread_. [[Eiden]] has something to do with this. 

## Notable NPCs
- 
# Meta Data
- Tags: #DnD/Levasa/Campaign_Notes 
- Campaign: [[Levasa]]
