---
aliases: Tanoq
Current Status: Alive
---
# Notable Locations
## Home
![[]]

---
# Biography

---
# Other Notes
## Languages
- #DnD/Language/Common 
- #DnD/Language/Dwarvish 
- #DnD/Language/Goblin
- #DnD/Language/Undercommon

---
# Related Articles

| Article Name | Relationship |
| ------------ | ------------ |
|              |              |
