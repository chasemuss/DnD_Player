---
aliases: 
---
# Significance
Capital of [[_Levasa|Levasa]]

# Sub-Locations
## The Palace
Home to the Free Family and the seat of power in [[_Levasa|Levasa]]

## Silver Songbird
Inn owned by Gustave Epensen

## The Flurries
The "ghetto" of Windsend, home to less than reputable people. Crumb is one of these people, but he typically has some interesting information.

# Related Articles
| Article | Relationship |
| ------- | ------------ |
|         |              |
