---
aliases: 
Current Status: 
---
# Notable Locations
## Home
![[]]

---
# Biography

---
# Other Notes
## Church of Bahamut
Headquartered in [[Windsend]]

| Name        | Role        |
| ----------- | ----------- |
| Bahamut     | Patron God  |
| Morduk      | Leader      |
| Edmond      | Book Keeper |
| Arvin       |             |
| [[Lorenzo]] |             |

## Languages
- 

---
# Related Articles

| Article Name | Relationship |
| ------------ | ------------ |
|              |              |
