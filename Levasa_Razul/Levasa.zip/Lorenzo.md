---
aliases: 
Current Status: Alive
---
# Notable Locations
## Home
![[]]

---
# Biography
An acolyte of [[Bahamut]] on the search for [[Anteres Free]]

---
# Other Notes
## Languages
- #DnD/Language/Common 
- #DnD/Language/Deep_Speech 
- #DnD/Language/Draconic 
- #DnD/Language/Dwarvish 
- #DnD/Language/Elvish 

---
# Related Articles

| Article Name | Relationship |
| ------------ | ------------ |
|              |              |
