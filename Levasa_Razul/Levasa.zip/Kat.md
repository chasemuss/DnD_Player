Current Status: #DnD/Levasa/Alive 
## Known Relatives

## Known Locations

## Goals & Desires

## Detests

## Flaws

## Pseudonyms

## Other Information
- Pilot of our airship & land cruiser