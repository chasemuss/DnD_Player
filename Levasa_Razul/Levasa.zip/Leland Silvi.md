# Leland Silvi
Current Status: #DnD/Levasa/Alive  
## Known Relatives

## Companions
- [[Red]]
- [[Friend]]
- [[Dan Jafari]]

## Known Locations

## Goals & Desires

## Detests

## Flaws

## Pseudonyms

## Other Information
- Owner of one of the #DnD/Levasa/Campaign_Notes/Seven_Instruments_of_Kirk 
- Former member of the [[Half-Moon Bloodhunters]]