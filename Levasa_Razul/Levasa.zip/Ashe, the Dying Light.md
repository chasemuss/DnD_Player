---
aliases: Ashe
Current Status: Alive
---
# Notable Locations
## Home
![[Windsend#The Flurries]]

---
# Biography
[Google Doc with BackStory](https://docs.google.com/document/d/1zDhXMBCWFgFe4vsgKRT-lFkdFMKqZ1mw0TF4OOWYo4s/edit?usp=sharing)

---
# Other Notes
## Languages
- #DnD/Language/Celestial
- #DnD/Language/Common 
- #DnD/Language/Elvish 
- #DnD/Language/Thieves_Cant

## Spells
- [[Class - Paladin#Oath of Vengeance Spells]]

---
# Related Articles

| Article Name | Relationship |
| ------------ | ------------ |
| [[Windsend]] | Hometown     | 
