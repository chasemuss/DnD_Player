# Razul Dazulson
Current Status: #DnD/Levasa/Alive 
## Known Relatives
- [[Dazul & Frazul]] (Father & Mother)

## Goals & Desires
- To acquire influence in high circles & prove his worth
- To be remembered forever as a hero

## Detests
- Being told what to do by people he doesn't respect

## Flaws
- Doesn't care for what others think

## Pseudonyms
- Irrelevant

## Other Information
Owner of one of the #DnD/Levasa/Campaign_Notes/Seven_Instruments_of_Kirk, used to summon [[Asmodeus]]