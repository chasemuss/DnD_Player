# Session 3: Actions have Consequences
## Recap
## Plot
We talked with Gecko and explained what happened. He said that we'd have to pay and it was decided (by the party & DM) that 15k GP would be the cost of relocating the town.

The amber miners in Obsidia work for [[Scale]].

We had a long conversation regarding the morality of our actions, and whether or not we could've taken on the demons in the mines.

We have a conversation with Azazel regarding his Contract Coin. This calls into question the ethics of the Coin, Enchantment Magic, and Detect Thoughts. Lyserah mentions that if she had the option, she wouldn't have put her soul as collateral in the Coin.

```ad-abstract
title: Magicks Contract
collapse: open

1) Azazel's Coin won't be used unless it is to protect someone's life, liberty, or property
2) Razul's Enchantment Spells won't be used unless it is to protect someone's life, liberty, or property
3) Dedera's Helm of Detect Thoughts won't be used unless it is to protect someone's life, liberty, or property
```

Next Morning:
Kat retells the following: "Gecko told the miners at the height of the drinking what happened and had to do what he could to stop them from killing us. Most of them will most likely not want to transplant to another city, and will stay here. There are some reasonable ones that will transplant, but it's unlikely."

We leave Obsidia

On our travel to Heartbeat, we are flagged down by a [Flumph](https://www.dndbeyond.com/monsters/flumph) floating and waving us down with what looks like paper detailing that [[Cultists of Seed]] are nearby, delivering it to Tanoq. We found a guy from Seed who was burned and dying. I tried to convince the cultist that I was a member of Seed, but he said I'm obviously not.

## Notable NPCs
- Lyserah
- Gecko
- Kat
# Meta Data
- Tags: #DnD/Levasa/Campaign_Notes/Magical_Contract
- Campaign: [[Levasa]]

