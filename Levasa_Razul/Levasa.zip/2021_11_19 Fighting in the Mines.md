# Session 1: Fighting in the Mines
## Recap
On the way to Heartbeat to get the blood of a Rakshasa for the Amber Cure, we stopped in Obsidia. Miners in Obsidia are being attacked by shadow creatures that they thought [[Lyserah]] was summoning. They were going to kill her, but the Party swept in and stopped them, saving Lyserah. 
## Plot
We are in a mine and there are [[Cultists of Seed]] performing a ritual, summoning a fire elemental. After disposing the cultists, we turned our focus to the elemental. After a long battle, we kill the elemental. I gather its ashes in a small bag. We meet a character named [[Lorenzo]] (Alex). He is an Acolyte of [[Church of Bahamut|Bahamut]] on the search for [[Antares]]. 
Lorenzo lived in a Monastery of Bahamut on the quest to see his family.
Levasa is a seed for Bane to plant into Sporos - [[Dedera]]
Sporos wants to blow up Levasa
[[Azazel]]'s Imp finds a note that says "Eradicate the Dwarves & Collect the #DnD/Levasa/Amber in Obsidia Mine"
There is a note on a gate that says "Don't open, Shadows inside"
## Notable NPCs
- Lyserah: Necromancer
# Meta Data
- Tags: #DnD/Levasa/Campaign_Notes
- Campaign: [[Levasa]]