# #Dnd/Levasa/Session/2022_02_04 - "All by Myself" - Razul

| Item           | Price (GP) | Quantity |
| -------------- | ---------- | -------- |
| Fire Bolts     | 25         | 20       |
| Dancing Rapier |            |          |
| +1 Rapier      | 1000       |          |

## Rakshasa Names
Rivana - Ruler of Rakshasas
Veepeeshana - Brother of Rivana; Not necessarily evil
Kumbakarna - Exceptionally Frightening; fat af
Hidemba - Cannibal
Gutukupcha - Sealed away by the evil Rakshasa (betrayed them?)
Jayadratha - Dead(?); 
Batkasura - Cannibal (fond of forest areas)
Karmira - Brother of Batkasura; Master Illusionist; Fond of Forests as well
Jotasura - Spends more time looking like animal than person; kills people; very deceptive and thief-like
Alamvusa - Especially good with illusions and at fighting

# #DnD/Levasa/Session/2021_03_04

