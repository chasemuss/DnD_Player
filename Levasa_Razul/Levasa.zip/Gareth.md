# Gareth
Current Status: #[Alive / Dead / Unknown]
## Known Relatives

## Known Locations

## Goals & Desires

## Detests

## Flaws

## Pseudonyms

## Other Information