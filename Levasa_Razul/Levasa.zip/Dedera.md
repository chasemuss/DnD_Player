# Dedera
Current Status: #DnD/Levasa/Alive 
## Known Relatives
- [[Yves]] (Biological Father)
- [[Shenna]] (Biological Mother)
- [[Shasta]] (Biological Maternal Aunt)
- [[Pierre]] (Grandfather)
- [[Walden]] (Great-Grandfather)
- [[King Remi]] (m. [[Solacea]]) (Uncle & Aunt)
- [[Jean]] (Cousin)
- [[Eliot]] (Trapped in Oka's Respite) (Cousin)
- [[Etienne]] (m. [[Fleur]]) (Adopted Father & Mother)
- [[Mael]] (Adopted Brother)
- [[Aimee]] (Adopted Sister)
- [[Lucius]] (Adopted Brother)
- [[Gael]] (m. [[Ann Gao]]) (Uncle & Aunt)
- [[Lorenzo]] (Cousin)
- [[Antares]] (Cousin)
- [[Alkaid]] (m. [[Tanis]]) (Cousin)
	- [[Eiden]]
## Goals & Desires
- Lead Levasa into a golden age

## Detests
- Uncontrolled Chaos

## Flaws

## Pseudonyms

## Other Information
- Owns [[Twilight Tower]]