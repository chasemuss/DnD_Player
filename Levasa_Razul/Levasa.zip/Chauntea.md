---
aliases: 
Current Status: 
---
# Notable Locations
## Home
![[]]

---
# Biography

---
# Other Notes
## Church of Chauntea
Headquartered in [[Windsend]]

| Name                       | Role       |
| -------------------------- | ---------- |
| Chauntea                   | Patron God |
| Ruth                       | Leader     |
| [[Ingrid Epensen\|Ingrid]] | Magister   |
| Danielle                   | Priestess  |

## Languages
- 

---
# Related Articles

| Article Name | Relationship |
| ------------ | ------------ |
|              |              |
