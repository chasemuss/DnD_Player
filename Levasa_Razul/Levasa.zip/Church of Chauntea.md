# Church of Chauntea
## Known Members
- [[Chauntea]]: Patron God
- [[Ruth]]: Leader
- [[Ingrid Epensen]] (Magister)
- [[Danielle]]: Priestess

## Other Connections

## Goals & Desires

## Pseudonyms

## Other Information
- Headquarters in [[Windsend]] 