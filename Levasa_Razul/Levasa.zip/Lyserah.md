---
aliases: 
Current Status: Alive
---
# Notable Locations
## Home
![[Obsidia]]

---
# Biography
Doesn't like the folks of [[Obsidia]] due to them killing her father and almost killing her, blaming her for the hellhounds that killed the miners. 

She made a contract with [[Azazel]] to be his student until he deemed her fit for society. 

---
# Other Notes
## Languages
- 

---
# Related Articles

| Article Name       | Relationship |
| ------------------ | ------------ |
| [[Azazel\|Azazel]] | Teacher      |

