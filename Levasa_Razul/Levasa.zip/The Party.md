# The Party
## Known Members
- [[Azazel]]
- [[Dedera]]
- [[Ingrid Epensen]]
- [[Lorenzo]]
- [[Razul]]
- [[Tanoq]]

## Other Connections
- [[Lyserah]]: Azazel's Apprentice
- [[Royal Family]]: Relatives of Dedera & Lorenzo

## Goals & Desires

## Pseudonyms

## Other Information