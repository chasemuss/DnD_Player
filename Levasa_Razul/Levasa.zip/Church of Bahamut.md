# Church of Bahamut
## Known Members
- [[Bahamut]]: Patron God
- [[Morduk]]: Leader
- [[Edmond]]: Book Keeper
- [[Arvin]]
## Other Connections

## Goals & Desires

## Pseudonyms

## Other Information
- Headquarters in [[Windsend]] 