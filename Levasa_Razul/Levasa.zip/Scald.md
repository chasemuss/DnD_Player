# Scald
Current Status: #DnD/Levasa/Unknown
## Known Relatives

## Known Locations

## Goals & Desires

## Detests

## Flaws

## Pseudonyms

## Other Information