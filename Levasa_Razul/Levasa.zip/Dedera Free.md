---
aliases: Dedera
Current Status: Alive 
---
# Notable Locations
## Home
![[Windsend#The Palace]]

---
# Biography

---
# Other Notes
## Languages
- #DnD/Language/Common 
- #DnD/Language/Dwarvish 
- #DnD/Language/Elvish 
- #DnD/Language/Primordial

---
# Related Articles

| Article Name | Relationship |
| ------------ | ------------ |
| [[Windsend]] | Hometown     |
|              |              |
