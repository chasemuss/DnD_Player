---
aliases: Razul
Current Status: Alive
---
# Notable Locations

## Home
[[Hotpot]]: ![[Hotpot]]

---
# Biography

---
# Other Notes
## Languages
- #DnD/Language/Common 
- #DnD/Language/Dwarvish 

---
# Related Articles

| Article Name | Relationship |
| ------------ | ------------ |
| [[Hotpot]]   | Hometown     |
