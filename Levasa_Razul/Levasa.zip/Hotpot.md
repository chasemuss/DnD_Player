# Hotpot
## Notable Events
## Sub-Locations
### Razul's Home
- [[Dazul & Frazul]]