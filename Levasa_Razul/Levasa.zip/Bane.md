---
aliases: Seed
Current Status: Alive
---
# Notable Locations
## Home
![[]]

---
# Biography

---
# Other Notes
## Cult of Seed
[[_Levasa|Levasa]] is a seed for Bane to plant into [[Sporos]]
## Languages
- 

---
# Related Articles

| Article Name | Relationship |
| ------------ | ------------ |
|              |              |
