# Table of Contents
## Character Sheet
[Razul, the Dazzling Bard](https://ddb.ac/characters/39392456/9vkFP3)
## Notes
- [[2021_11_19 Fighting in the Mines]]
- [[2021_11_26 Delving Deeper into the Mines]]
- [[2021_12_03 Actions have Consequences]]
- [[2021_12_10 Cultists & Shrooms]]
## World Information
### Factions
- [[Church of Bahamut]]
- [[Church of Chauntea]]
- [[Cultists of Seed]]
- [[Half-Moon Bloodhunters]]
- [[Order of the Twilight Lotus]]
- [[Scale]]
- [[The Mew]]
- [[The Party]]
- [[Royal Family]]