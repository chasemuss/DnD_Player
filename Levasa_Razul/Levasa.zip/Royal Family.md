# Royal Family
## Walden
### Pierre
#### Yves
- Dedera (Biological)

Shenna is is mom and Shasta is his aunt

#### King Remi (m. Solacea)
- Jean 
- Eliot (Trapped in Oka's Respite)
#### Etienne (m. Fleur)
- Dedera (Adopted)
- Mael
- Aimee
- Lucius
#### Gael (m. Ann Gao)
- Lorenzo
- Eiden
- Antares
- Alkaid (m. Tanis): Has a baby