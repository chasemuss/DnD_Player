# Gustave Epensen
Current Status: #DnD/Levasa/Alive 
## Known Relatives
- [[Ingrid Epensen]]

## Known Locations
- [[Windsend#The Silver Songbird]]

## Goals & Desires

## Detests

## Flaws

## Pseudonyms

## Other Information