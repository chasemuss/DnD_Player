# Half-Moon Bloodhunters
## Known Members

### Former Members
- [[Leland Silvi]]
## Other Connections

## Goals & Desires

## Pseudonyms

## Other Information