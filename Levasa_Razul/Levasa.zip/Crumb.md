# Crumb
Current Status: #DnD/Levasa/Alive
## Known Relatives

## Known Locations
[[Windsend#The Flurries]]
## Goals & Desires

## Detests

## Flaws

## Pseudonyms

## Other Information
- Typically has interesting information