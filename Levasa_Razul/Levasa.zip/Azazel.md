---
aliases: Azazel
Current Status: Alive
---
# Notable Locations
## Home
![[]]

---
# Biography

---
# Other Notes
## Languages
- #DnD/Language/Common 
- #DnD/Language/Deep_Speech
- #DnD/Language/Elvish 
- #DnD/Language/Infernal 

---
# Related Articles

| Article Name | Relationship |
| ------------ | ------------ |
| [[Asmodeus]] | Father       |
| [[Lyserah]]  | Student      |
