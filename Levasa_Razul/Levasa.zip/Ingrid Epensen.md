---
aliases: Ingrid
Current Status: Alive 
---
# Notable Locations
## Home
![[Windsend#Silver Songbird]]

---
# Biography

---
# Other Notes
## Languages
- #DnD/Language/Common 
- #DnD/Language/Dwarvish 
- #DnD/Language/Elvish 
- #DnD/Language/Orc 

---
# Related Articles

| Article Name                    | Relationship |
| ------------------------------- | ------------ |
| [[Chauntea#Church of Chauntea]] | Member       |
|                                 |              |

